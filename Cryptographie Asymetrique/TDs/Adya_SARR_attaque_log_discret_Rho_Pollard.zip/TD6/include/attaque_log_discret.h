#if !defined(ATTAQUE_LOG_DISCRET_H)
#define ATTAQUE_LOG_DISCRET_H

typedef struct 
{
    int alpha_i;
    int beta_i;
}puissance_alpha_i;

/**
 * Je passe a l'algorithme d'euclide etendue ou je calcule a la fois le pgcd deux entiers a et b en plus deux entier x et y tels
 * que ax + by = PGCD(a, b)
 * Etape 1: Definir la structure me permettant de le faire
 * Etape 2: l'implementation de la fonction
 */
typedef struct 
{
    int pgcd;
    int x;
    int y;
}params_euclide_etendu;


/**
 * @brief Cette fonction permet de trouver le log discret d'un element dans une base g
 * @param order: ordre du groupe G
 * @param gen: generateur du goupe G
 * @param elem: l'element dont on veut sa log discret
 */
int attaque_Rho_Pollard(int order, int gen, int elem);
#endif // ATTAQUE_LOG_DISCRET_H
