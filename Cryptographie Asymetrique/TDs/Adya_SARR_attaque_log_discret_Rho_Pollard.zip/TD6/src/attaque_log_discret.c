#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../include/attaque_log_discret.h"


params_euclide_etendu *euclide_etendu(int entier1, int entier2){
    params_euclide_etendu *resultat = malloc(sizeof(params_euclide_etendu));
    if (!resultat)
    {
        fprintf(stderr, "malloc: sur l'allocation des parametres d'euclide etendu\n");
        return NULL;
    }
    int max = (entier1>entier2? entier1:entier2);
    int min;
    if (max == entier1)
    {
        min = entier2;
    }else
    {
        min = entier1;
    }
    int quotien = 0;
    int reste = 0;
    int x_0 = 1;
    int x_1 = 0;
    int y_0 = 0;
    int y_1 = 1;
    int x_2, y_2; 
    do
    {
        quotien = max/min;
        reste = max - min*quotien;
        x_2 = x_0 - x_1*quotien;
        y_2 = y_0 - y_1*quotien;
        
        max = min;
        min = reste;

        x_0 = x_1;
        x_1 = x_2;

        y_0 = y_1;
        y_1 = y_2;
    } while (reste!=0);
    resultat->pgcd = max;
    resultat->x = x_0;
    resultat->y = y_0;

    return resultat;
}

int inverse_mod(const int entier,const int mod){
    int inv = 0;
    params_euclide_etendu *result = euclide_etendu(entier, mod);
    if (!result)
    {
        fprintf(stderr, "probleme d'allocation sur la fonction inverse_mod\n");
        return -1;
    }

    if (result->pgcd != 1)
    {
        return -1;
    }
    inv = result->x;
    if (inv < 0) {
        inv += mod;
    }
    free(result);
    return inv;
}

int attaque_Rho_Pollard(int order, int gen, int elem){
    //S_1 = {k congru 1 mod3}
    //S_2 = {k congru 0 mod3}
    //S_3 = {k congru 2 mod3}
    int y_0 = 1;
    // Alors y_0 n'est pas dans S_2 et y_0 est dans S_1 dou y_1 = elem*y_0
    int y_i = y_0;
    int y_2i =  y_i*y_i*y_i*y_i;
    puissance_alpha_i *params_alpah_i = malloc(sizeof(puissance_alpha_i));
    if (!params_alpah_i)
    {
        fprintf(stderr, "malloc: erreur d'allocation");
        return -1;
    }
    
    puissance_alpha_i *params_alpah_2i = malloc(sizeof(puissance_alpha_i));
    if (!params_alpah_2i)
    {
        fprintf(stderr, "malloc: erreur d'allocation");
        return -1;
    }
    params_alpah_i->alpha_i = 1;
    params_alpah_i->beta_i= 1;
    params_alpah_2i->alpha_i = 4*params_alpah_i->alpha_i;
    params_alpah_2i->beta_i = 4*params_alpah_i->beta_i;
    do
    {
        params_alpah_i->alpha_i = params_alpah_2i->alpha_i;
        params_alpah_i->beta_i = params_alpah_2i->beta_i;
        y_i = y_2i;
        if (y_i%3 == 0)// donc on est dans l'ensemble S_2 dou y_2i = F(F(y_i)) = F(y^2) = (y^4)
        {
            params_alpah_2i->alpha_i = 4*params_alpah_i->alpha_i;
            params_alpah_2i->beta_i = 4*params_alpah_i->beta_i;
            y_2i = y_i*y_i*y_i*y_i;
        }else if (y_i*3==1)//S1: dans ce cas y_2i = F(F(y_i)) = F(elem*y_i) = elem*elem*y_i
        {
            params_alpah_2i->alpha_i = params_alpah_i->alpha_i;
            params_alpah_2i->beta_i = params_alpah_i->beta_i + 2;
            y_2i = elem*elem*y_i;
        }else//dans S3: y_2i = F(F(y_i)) = F(gen*y_i)=g*g*y_i
        {
            params_alpah_2i->alpha_i = params_alpah_i->alpha_i+2;
            params_alpah_2i->beta_i = params_alpah_i->beta_i;
            y_2i = gen*gen*y_i;
        }
    } while (y_i != y_2i);
     
    int x;
    /* printf("%d\n", y_i);
    printf("%d\n", y_2i);
    printf("%d\n", params_alpah_2i->alpha_i);
    printf("%d\n", params_alpah_2i->beta_i);
    printf("%d\n", params_alpah_i->alpha_i);
    printf("%d\n", params_alpah_i->beta_i); */
    x = (params_alpah_2i->alpha_i - params_alpah_i->alpha_i)*inverse_mod(params_alpah_i->beta_i - params_alpah_2i->beta_i, order);
    free(params_alpah_2i);
    free(params_alpah_i);
    x=x%order;
    if (x<0)
    {
        x+=order;
    }
    
    return x;
}

int main(int argc, char const *argv[])
{
    int x = attaque_Rho_Pollard(382, 2, 229);
    printf("%d\n", x);
    return 0;
}
