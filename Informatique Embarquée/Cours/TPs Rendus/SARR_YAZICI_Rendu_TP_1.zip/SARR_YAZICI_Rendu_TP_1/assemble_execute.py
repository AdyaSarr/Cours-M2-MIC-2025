import sys
from enum import Enum

registers = [0] * 64  # 64 registres initialisés à 0
memory = [0] * 4096  # 4096 emplacements mémoire initialisés à 0

# Notre représentation binaire de chaque opération
class Operation(Enum) :
    ADD = "00000001"
    SUB = "00000010"
    MUL = "00000011"
    DIV = "00000100"
    AND = "00000101"
    OR = "00000110"
    XOR = "00000111"
    ADDI = "00001000"
    SUBI = "00001001"
    MULI = "00001010"
    DIVI = "00001011"
    ANDI = "00001100"
    ORI = "00001101"
    XORI = "00001110"
    LW = "00001111"
    SW = "00010000"
    BEQ = "00010001"
    BNE = "00010010"
    BLO = "00010011"
    BGT = "00010100"

# Fonction simple pour parser une ligne d'instruction
def parse_line(line) :
    parts = line.strip().split()
    if not parts:
        return None
    op = parts[0].upper()
    args = [int(x.strip(',')) for x in parts[1:]]
    return op, args

# Fonction pour encoder une instruction en binaire
def encode_instruction(op, args) :
    opcode = Operation[op].value

    r_ops = {Operation.ADD, Operation.SUB, Operation.MUL, Operation.DIV, Operation.AND, Operation.OR, Operation.XOR}
    i_ops = {Operation.ADDI, Operation.SUBI, Operation.MULI, Operation.DIVI, Operation.ANDI, Operation.ORI, Operation.XORI}
    lw_sw_ops = {Operation.LW, Operation.SW}
    branch_ops = {Operation.BEQ, Operation.BNE, Operation.BLO, Operation.BGT}

    op_enum = Operation[op]

    if op_enum in r_ops :
        # OP r1, r2, r3 : OP(8) r2(6) r3(6) r1(6) 000000(6)
        r1, r2, r3 = args
        bin_str = (
            opcode +
            f"{r2:06b}" +
            f"{r3:06b}" +
            f"{r1:06b}" +
            "000000"
        )
    elif op_enum in i_ops :
        # OP r1, r2, cst : OP(8) r2(6) cst(12) r1(6)
        r1, r2, cst = args
        bin_str = (
            opcode +
            f"{r2:06b}" +
            f"{cst:012b}" +
            f"{r1:06b}"
        )
    elif op_enum in lw_sw_ops :
        # lw/sw r1, cst(r2) : OP(8) r2(6) cst(12) r1(6)
        r1, r2, cst = args
        bin_str = (
            opcode +
            f"{r2:06b}" +
            f"{cst:012b}" +
            f"{r1:06b}"
        )
    elif op_enum in branch_ops :
        # OP r1, r2, label : OP(8) r2(6) r1(6) label(12)
        r1, r2, label = args
        bin_str = (
            opcode +
            f"{r2:06b}" +
            f"{r1:06b}" +
            f"{label:012b}"
        )
    else:
        raise ValueError(f"Opération inconnu : {op}")

    # On veut être sûr que l'instruction fait 32 bits
    if len(bin_str) != 32 :
        raise ValueError(f"Erreur d'encodage d'instruction : {bin_str} n'est pas sur 32 bits")
    return bin_str

def assemble_file(input_file, output_file) :
    instructions = []
    with open(input_file, "r") as f :
        for line_num, line in enumerate(f, 1) :
            try:
                parsed = parse_line(line)
                if parsed:
                    op, args = parsed
                    # Vérification du nombre d'arguments selon l'opération
                    op_enum = Operation[op]
                    if op_enum in {Operation.ADD, Operation.SUB, Operation.MUL, Operation.DIV, Operation.AND, Operation.OR, Operation.XOR} :
                        if len(args) != 3 :
                            raise ValueError(f"'{line.strip()}' attend 3 arguments (r1, r2, r3)")
                    elif op_enum in {Operation.ADDI, Operation.SUBI, Operation.MULI, Operation.DIVI, Operation.ANDI, Operation.ORI, Operation.XORI} :
                        if len(args) != 3 :
                            raise ValueError(f"'{line.strip()}' attend 3 arguments (r1, r2, cst)")
                    elif op_enum in {Operation.LW, Operation.SW} :
                        if len(args) != 3 :
                            raise ValueError(f"'{line.strip()}' attend 3 arguments (r1, r2, cst)")
                    elif op_enum in {Operation.BEQ, Operation.BNE, Operation.BLO, Operation.BGT} :
                        if len(args) != 3 :
                            raise ValueError(f"'{line.strip()}' attend 3 arguments (r1, r2, label)")
                    bin_str = encode_instruction(op, args)
                    instructions.append(bin_str)
            except KeyError:
                raise ValueError(f"Ligne {line_num}: Opération inconnue '{line.strip()}'")
            except Exception as e:
                raise ValueError(f"Ligne {line_num}: Erreur - {e}")
    with open(output_file, "wb") as f :
        for bin_str in instructions:
            byte_arr = int(bin_str, 2).to_bytes(len(bin_str)//8, byteorder='big')
            f.write(byte_arr)

# Fonction pour décoder une instruction binaire et la rendre utilisable pour l'exécution
def decode_instruction(bin_str) :
    op_code = bin_str[:8]
    for op in Operation :
        if op.value == op_code :
            op_enum = op
            break
    else:
        raise ValueError(f"Opération inconnu : {op_code}")

    if op_enum in {Operation.ADD, Operation.SUB, Operation.MUL, Operation.DIV, Operation.AND, Operation.OR, Operation.XOR} :
        r2 = int(bin_str[8:14], 2)
        r3 = int(bin_str[14:20], 2)
        r1 = int(bin_str[20:26], 2)
        return op_enum, [r1, r2, r3]
    elif op_enum in {Operation.ADDI, Operation.SUBI, Operation.MULI, Operation.DIVI, Operation.ANDI, Operation.ORI, Operation.XORI} :
        r2 = int(bin_str[8:14], 2)
        cst = int(bin_str[14:26], 2)
        r1 = int(bin_str[26:32], 2)
        return op_enum, [r1, r2, cst]
    elif op_enum in {Operation.LW, Operation.SW} :
        r2 = int(bin_str[8:14], 2)
        cst = int(bin_str[14:26], 2)
        r1 = int(bin_str[26:32], 2)
        return op_enum, [r1, r2, cst]
    elif op_enum in {Operation.BEQ, Operation.BNE, Operation.BLO, Operation.BGT} :
        r2 = int(bin_str[8:14], 2)
        r1 = int(bin_str[14:20], 2)
        label = int(bin_str[20:32], 2)
        return op_enum, [r1, r2, label]
    else:
        raise ValueError(f"Opération inconnu : {op_enum}")

def execute_binary_file(binary_file) :
    with open(binary_file, "rb") as f :      # On lit le fichier binaire
        code = f.read()
    instructions = []
    for i in range(0, len(code), 4) :   # On remplit notre liste d'instructions
        instr_bytes = code[i:i+4]
        bin_str = ''.join(f"{byte:08b}" for byte in instr_bytes)
        instructions.append(bin_str)

    pc = 0  # Compteur de programme
    while pc < len(instructions) :
        op_enum, args = decode_instruction(instructions[pc])
        print(f"PC = {pc} : {op_enum.name} {args}")     # On affiche l'instruction en cours d'exécution
        if op_enum == Operation.ADD :
            r1, r2, r3 = args
            registers[r1] = registers[r2] + registers[r3]
        elif op_enum == Operation.SUB :
            r1, r2, r3 = args
            registers[r1] = registers[r2] - registers[r3]
        elif op_enum == Operation.MUL :
            r1, r2, r3 = args
            registers[r1] = registers[r2] * registers[r3]
        elif op_enum == Operation.DIV :
            r1, r2, r3 = args
            registers[r1] = registers[r2] // registers[r3] if registers[r3] != 0 else 0
        elif op_enum == Operation.AND :
            r1, r2, r3 = args
            registers[r1] = registers[r2] & registers[r3]
        elif op_enum == Operation.OR :
            r1, r2, r3 = args
            registers[r1] = registers[r2] | registers[r3]
        elif op_enum == Operation.XOR :
            r1, r2, r3 = args
            registers[r1] = registers[r2] ^ registers[r3]
        elif op_enum == Operation.ADDI :
            r1, r2, cst = args
            registers[r1] = registers[r2] + cst
        elif op_enum == Operation.SUBI :
            r1, r2, cst = args
            registers[r1] = registers[r2] - cst
        elif op_enum == Operation.MULI :
            r1, r2, cst = args
            registers[r1] = registers[r2] * cst
        elif op_enum == Operation.DIVI :
            r1, r2, cst = args
            registers[r1] = registers[r2] // cst if cst != 0 else 0
        elif op_enum == Operation.ANDI :
            r1, r2, cst = args
            registers[r1] = registers[r2] & cst
        elif op_enum == Operation.ORI :
            r1, r2, cst = args
            registers[r1] = registers[r2] | cst
        elif op_enum == Operation.XORI :
            r1, r2, cst = args
            registers[r1] = registers[r2] ^ cst
        elif op_enum == Operation.LW :
            r1, r2, cst = args
            addr = registers[r2] + cst
            if 0 <= addr < len(memory) :
                registers[r1] = memory[addr]
            else:
                print(f"Accès mémoire hors limites : {addr}")
        elif op_enum == Operation.SW :
            r1, r2, cst = args
            addr = registers[r2] + cst
            if 0 <= addr < len(memory) :
                memory[addr] = registers[r1]
            else:
                print(f"Accès mémoire hors limites : {addr}")
        elif op_enum == Operation.BEQ :
            r1, r2, label = args
            if registers[r1] == registers[r2] :
                pc = label // 4
                continue
        elif op_enum == Operation.BNE :
            r1, r2, label = args
            if registers[r1] != registers[r2] :
                pc = label // 4
                continue
        elif op_enum == Operation.BLO :
            r1, r2, label = args
            if registers[r1] < registers[r2] :
                pc = label // 4
                continue
        elif op_enum == Operation.BGT :
            r1, r2, label = args
            if registers[r1] > registers[r2] :
                pc = label // 4
                continue
        pc += 1

def main():
    if len(sys.argv) == 3 :         # Mode assemblage du fichier texte vers binaire
        input_file = sys.argv[1]    # Fichier d'entrée (texte)
        output_file = sys.argv[2]   # Fichier de sortie (binaire)
        assemble_file(input_file, output_file)
    elif len(sys.argv) == 2 :        # Mode exécution d'un fichier binaire
        binary_file = sys.argv[1]
        execute_binary_file(binary_file)
        print("Registres (les 10 premiers) :", registers[:10])
        print("Mémoire (les 10 premiers) :", memory[:10])
    else:                   # Aide
        print("Usage:")
        print("  Assemble: python assemble_execute.py <input.txt> <output.bin>")
        print("  Execute: python assemble_execute.py <input.bin>")
        sys.exit(1)

if __name__ == "__main__" :
    main()